====================
MnB SaveGame Editor
====================


MnB SaveGame Editor, is a tool which let you edit save game and convert from a mod's version to another.
Maybe useful for mod debugging, recover old version save games, role play.




===================Modify a save game

-Click "Import new save..."
-Select Module directory and a savegame. Then click load. ("MountBlade Warband\Modules\Native" folder, if the save doesn't use a mod)
-Modify some values
-Click "Export Current Save" and choose a output file.

You cannot add entries, only modify. And you may not modify variables with "num_" in the name.
Insure your values are coherents.
If you wish to modify player's party troop_ids, insure you replace heroes by heroes or non-heroes by non-heroes troops.
Otherwise the final file may be corrupted. I hope this limitation to be removed in later versions.
AND PLEASE, DO NOT ABUSE CHEATING !

Here is the link to the structure : mbmodwiki.ollclan.eu/Savegame
Thanks to cmpxchg8b, he did a really good job.



===================Convert a save game to another mod's version

You need the save and mod installed, and also the new version of the mod installed, with a random save game as example. (just start a new game and save it)

-Load the save you wish to convert.
-Load the example save from the recent mod version.
-Click 'Convert Save...'
-Select the two saves, and check all the data you wish to convert. The less is checked the less bugs you may encounter. But going with default settings should do it well.
-Click "Export Current Save" and choose a output file. (Please, watch out to not to override your current saves)


===================How the program works

In order to display correct value stored in the save game, this program uses a "SaveGameStructure.txt" which describes save game structure and "SlotsNames.txt" which helps giving names to slots.
They also tell how the value should be converted, there are different possible behaviours :

    DONTREPLACE = 0			e.g. num_triggers :o
    REPLACE = 1				e.g. Player's Level
    CLEAR = 2				e.g. game log

    DONTREPLACE_EXCEPTPLAYERS = 3,	e.g. troops faces
    REPLACE_EXCEPTPLAYERS = 4,		.

These next ones try to find new IDs. If the IDs number changed, but the name remains the same, the program will find and replace with new ID number.
If the new version's ID's name is missing (troop or faction is deleted by the update) then the value is not replaced.

    REPLACE_BY_FACTION_ID		
    REPLACE_BY_GLOBALVAR_ID
    REPLACE_BY_PARTY_ID
    REPLACE_BY_PARTY_TEMPLATE_ID	
    REPLACE_BY_PARTY_RECORD_ID
    REPLACE_BY_QUEST_ID
    REPLACE_BY_SCENE_ID
    REPLACE_BY_TROOP_ID
    REPLACE_BY_ITEM_ID


IDs are gathered from Modules files while the save is loaded.
"SlotsNames" came from Warband module system's file "module_constants.py". This file may differ from mod to mod.
It often looks like Native's one, but having mods "module_constants.py" would help a lot, and make things safer.

Editing "SaveGameStructure.txt" and "SlotsNames.txt" is really not recommended. But I admit I wasn't sure which behaviour to give to some entries sometimes.



===================Known Bugs

-crashes if program exceed about 1.7 GB in RAM (so loading more than 2 save is not advised)
-loading progress not correct
-modifying "num_" variables corrupt save game
-modifying player troops / player_party_stack_additional_info may cause file to be corrupted.


If you find any bugs your are welcome to share at the MnB SaveGame Editor thread on the forum http://forums.taleworlds.com/.
As same for any feedback, asking for help etc.


====================Patch notes 

--v1.02 - november 2nd, 2014
-Fixed : new support 1.161 version (changes in game save structure)

--v1.02 - may 25th, 2014
-Fixed : save game not loading with specific mods

--v1.01 - may 3rd, 2014
-Transfer faction relations smarter (by recognizing names)



Enjoy,
and do not abuse this program, :)
Kushulain.